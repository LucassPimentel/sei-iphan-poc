# =============================================================================
# 04_entidades.R
# Extracao de entidades e relacoes dos documentos nativos (POC IPHAN)
#
# Responsabilidade: Camada de Conteudo — extracao de ENTIDADES/RELACOES.
#   Diferente de 05_text_mining.R (que produz atributos textuais para
#   modelagem), esta etapa captura informacao ESTRUTURAL que alimenta o event
#   log, o grafo organizacional e a analise de conformidade (etapas 07-10):
#     - remetente/signatario (nome, cargo)
#     - unidade emissora      (do cabecalho do documento)
#     - destinatario          (nome, cargo/unidade)
#     - prazo legal           (data-limite "encerrar-se-a em DD/MM/AAAA")
#
# Motivacao (definida com o pesquisador):
#   Os nomes de signatarios/destinatarios sao removidos do TF-IDF (nao sao
#   termos tematicos), mas NAO devem ser descartados: o grafo precisa saber
#   quem solicitou o que a quem, entre quais unidades, e ate que prazo — para
#   avaliar atraso/conformidade. Esta etapa persiste essa informacao numa
#   estrutura propria, separada do vocabulario textual.
#
# Regras de extracao — baseadas em padroes REAIS observados nos documentos:
#   - Destinatario : "Ao Senhor|A Senhora <NOME MAIUSCULO> <cargo/unidade>"
#                    (confirmado em todos os oficios do processo 01450.002827).
#   - Remetente    : "assinado eletronicamente por <NOME>, <CARGO>"
#                    (padrao fixo do rodape do SEI, reaproveitado do 05).
#   - Unidade emiss.: sigla no numero do documento "Oficio nº .../<UNID>-IPHAN".
#   - Prazo        : "prazo legal para manifestacao do IPHAN encerrar-se-a em
#                    DD/MM/AAAA" (confirmado apenas em Despachos que calculam
#                    prazo — ex.: Despacho CGM).
#
# Limitacoes registradas (ver research-methodology.md):
#   - As regras dependem do texto ja extraido COM separadores (03 corrigido).
#     Se o texto vier colado, a captura de nome/unidade degrada.
#   - Documentos fora do padrao (ex.: destinatario externo, pessoa fisica) sao
#     capturados de forma parcial e marcados; a cobertura e medida, nao
#     assumida.
#   - Nao inventamos entidade: quando o padrao nao casa, o campo fica NA e a
#     ausencia e contabilizada.
#
# Tecnologias: stringr, stringi, tibble, dplyr, purrr, lubridate, jsonlite
# =============================================================================

library(stringr)
library(stringi)
library(tibble)
library(dplyr)
library(purrr)
library(lubridate)
library(jsonlite)

# -----------------------------------------------------------------------------
# Constantes: padroes de extracao (documentados, nao hardcode disperso)
# -----------------------------------------------------------------------------

# Destinatario: "Ao Senhor" ou "A Senhora" seguido de NOME em caixa alta.
# O nome e uma sequencia de palavras majoritariamente em maiusculas.
PADRAO_DESTINATARIO_ABERTURA <- "\\b(Ao Senhor|\u00c0 Senhora|A Senhora|Ao Senhora|Aos Senhores)\\b"

# Prazo legal — Camada 1: frase explicita (alta confianca), observada nos
# despachos de calculo de prazo.
PADRAO_PRAZO <- paste0(
  "prazo legal para manifesta\u00e7\u00e3o do IPHAN\\s+encerrar-se-\u00e1\\s+em\\s+",
  "(\\d{2}/\\d{2}/\\d{4})"
)

# Prazo legal — Camada 2: gatilhos de proximidade. Uma data proxima de uma
# destas palavras e candidata a prazo. Lista EDITAVEL (dado, nao code disperso);
# cobre variacoes sem exigir a frase exata (ex.: "prazo assinalado (DATA)",
# "observar o prazo ... DATA", "encerra em DATA", "ate DATA").
GATILHOS_PRAZO <- c("prazo", "encerr", "assinalad", "observ", "at\u00e9 o dia", "vencimento", "limite")

# Anti-gatilhos: se a data estiver proxima destes termos, e data de ASSINATURA
# ou de gera\u00e7\u00e3o do documento — NAO e prazo.
ANTIGATILHOS_PRAZO <- c("assinado eletronicamente", "\u00e0s", "autenticidade", "Decreto")

# Janela (em caracteres) ao redor da data para procurar gatilhos.
JANELA_PRAZO <- 45L

# Remetente pelo rodape de assinatura (mesmo padrao usado no 05).
PADRAO_REMETENTE <- "assinado eletronicamente por\\s+([^,]+),\\s*([^,]+?),\\s*em\\b"

# Unidade emissora: sigla no numero do documento, ex.:
#   "Of\u00edcio n\u00ba 156/2026/ETL-BA/IPHAN-BA-IPHAN" -> ETL-BA / IPHAN-BA
PADRAO_UNIDADE_EMISSORA <- "n[\u00ba\u00b0o]\\s*\\d+/\\d{4}/([A-Z0-9\\-/]+)"

# -----------------------------------------------------------------------------
# 1. Destinatario
# -----------------------------------------------------------------------------

#' Extrai o destinatario de um documento a partir do corpo do texto.
#'
#' Padrao (confirmado nos oficios reais):
#'   "Ao Senhor <NOME EM MAIUSCULAS> <cargo/unidade em texto normal> Assunto:"
#'
#' Estrategia:
#'   1. Localiza a abertura ("Ao Senhor"/"A Senhora").
#'   2. Captura, logo apos, a sequencia de palavras em CAIXA ALTA como nome.
#'   3. Captura o trecho seguinte (cargo/unidade) ate um delimitador
#'      ("Assunto", "Prezado", "Processo", quebra ou fim).
#'
# Palavra de nome: maiuscula (2+ letras). Usada na extracao do nome.
PALAVRA_NOME <- "[A-Z\u00c0-\u00dc][A-Z\u00c0-\u00dc'\\.]+"

# Delimitadores que encerram o bloco de cargo/unidade de um destinatario.
DELIM_FIM_CARGO <- "(?:Assunto|Ao Senhor|\u00c0 Senhora|A Senhora|Prezad|Senhor[ae]? Superintendente|Processo n|Ref\\.|Ref:|Cordialmente|E-mail:|$)"

#' Extrai nome e cargo/unidade de UM bloco de destinatario (texto ja iniciado
#' logo apos "Ao Senhor"/"A Senhora", ate o proximo delimitador).
#'
#' @param bloco Trecho de texto do destinatario
#' @return list(nome, cargo) ou NULL se nao houver nome
.parse_bloco_destinatario <- function(bloco) {
  # Remove zero-width spaces (U+200B/FEFF) que o SEI insere no texto e que o
  # str_squish nao trata, poluindo nome/cargo.
  bloco <- stri_replace_all_regex(bloco, "[\\u200B\\uFEFF]", "")
  bloco <- str_squish(bloco)
  if (bloco == "") return(NULL)

  # Nome: palavras maiusculas, com "E" aceito APENAS entre palavras (nunca como
  # ultimo token). Captura "...GUANAIS E QUEIROZ" sem engolir "E" de "Energias".
  padrao_nome <- paste0("^(?:(?:", PALAVRA_NOME, "|E)\\s+){1,8}", PALAVRA_NOME)
  nome <- str_extract(bloco, padrao_nome)
  if (is.na(nome)) nome <- str_extract(bloco, paste0("^", PALAVRA_NOME))
  if (is.na(nome)) return(NULL)
  nome <- str_squish(nome)

  # Cargo/unidade: o que sobra apos o nome, ate um delimitador conhecido.
  apos_nome <- str_squish(substr(bloco, nchar(nome) + 1, nchar(bloco)))
  cargo <- str_extract(apos_nome, paste0("^.*?(?=\\s+", DELIM_FIM_CARGO, ")"))
  if (is.na(cargo) || cargo == "") cargo <- str_squish(substr(apos_nome, 1, 120))
  cargo <- str_squish(cargo)
  if (cargo == "") cargo <- NA_character_

  list(nome = nome, cargo = cargo)
}

#' Extrai TODOS os destinatarios de um documento.
#'
#' Documentos podem ter mais de um destinatario, cada um introduzido por
#' "Ao Senhor"/"A Senhora". O bloco de cada destinatario vai da sua abertura
#' ate a proxima abertura (ou ate um delimitador como "Assunto:").
#'
#' Retorno mantem compatibilidade tabular: destinatario_nome/destinatario_cargo
#' referem-se ao PRIMEIRO destinatario; a lista completa fica em `destinatarios`
#' e a contagem em `n_destinatarios`.
#'
#' @param texto Texto completo do documento (corpo)
#' @return list(destinatario_nome, destinatario_cargo, destinatario_encontrado,
#'              n_destinatarios, destinatarios)
extrair_destinatario <- function(texto) {
  vazio <- list(destinatario_nome = NA_character_,
                destinatario_cargo = NA_character_,
                destinatario_encontrado = FALSE,
                n_destinatarios = 0L,
                destinatarios = list())
  if (is.na(texto) || texto == "") return(vazio)

  # Todas as aberturas de destinatario
  aberturas <- str_locate_all(texto, PADRAO_DESTINATARIO_ABERTURA)[[1]]
  if (nrow(aberturas) == 0) return(vazio)

  inicios <- aberturas[, 1]  # inicio de cada "Ao Senhor/A Senhora"
  fins_ab <- aberturas[, 2]  # fim da expressao de abertura

  destinatarios <- list()
  for (k in seq_len(nrow(aberturas))) {
    # O bloco vai do fim desta abertura ate o inicio da proxima (ou fim do texto)
    ini <- fins_ab[k] + 1
    fim <- if (k < nrow(aberturas)) inicios[k + 1] - 1 else nchar(texto)
    bloco <- substr(texto, ini, fim)

    parsed <- .parse_bloco_destinatario(bloco)
    if (!is.null(parsed)) {
      destinatarios[[length(destinatarios) + 1]] <- parsed
    }
  }

  if (length(destinatarios) == 0) return(vazio)

  list(
    destinatario_nome        = destinatarios[[1]]$nome,
    destinatario_cargo       = destinatarios[[1]]$cargo,
    destinatario_encontrado  = TRUE,
    n_destinatarios          = length(destinatarios),
    destinatarios            = destinatarios
  )
}

# -----------------------------------------------------------------------------
# 2. Remetente / signatario + unidade emissora
# -----------------------------------------------------------------------------

#' Extrai o(s) remetente(s)/signatario(s) do bloco de assinatura.
#'
#' Reutiliza o padrao fixo do rodape do SEI. Pode haver mais de um signatario
#' (ex.: chefe + coordenador). Retorna o primeiro como principal e a contagem.
#'
#' @param bloco_assinaturas Texto do bloco de assinatura (do 05/separar_boilerplate)
#' @return list(remetente_nome, remetente_cargo, n_signatarios)
extrair_remetente <- function(bloco_assinaturas) {
  vazio <- list(remetente_nome = NA_character_,
                remetente_cargo = NA_character_,
                n_signatarios = 0L)
  if (is.null(bloco_assinaturas) || length(bloco_assinaturas) == 0 ||
      is.na(bloco_assinaturas) || bloco_assinaturas == "") {
    return(vazio)
  }

  m <- str_match_all(bloco_assinaturas, PADRAO_REMETENTE)[[1]]
  if (nrow(m) == 0) return(vazio)

  list(
    remetente_nome  = str_squish(m[1, 2]),
    remetente_cargo = str_squish(m[1, 3]),
    n_signatarios   = nrow(m)
  )
}

#' Extrai a sigla da unidade emissora a partir do numero do documento.
#'
#' Ex.: "Of\u00edcio n\u00ba 156/2026/ETL-BA/IPHAN-BA-IPHAN" -> "ETL-BA/IPHAN-BA-IPHAN".
#' Retorna o bloco de siglas como aparece; a normalizacao fina (ex.: IPHAN-BA)
#' fica para a etapa de grafo, que consolida unidades.
#'
#' @param texto Texto do documento (o numero costuma estar no inicio)
#' @return character (sigla/bloco de unidade) ou NA
extrair_unidade_emissora <- function(texto) {
  if (is.na(texto) || texto == "") return(NA_character_)
  m <- str_match(texto, PADRAO_UNIDADE_EMISSORA)
  if (is.na(m[1, 2])) return(NA_character_)
  str_squish(m[1, 2])
}

# -----------------------------------------------------------------------------
# 3. Prazo legal
# -----------------------------------------------------------------------------

#' Extrai a data-limite do prazo, em camadas (da mais confiavel a mais generica).
#'
#' Em vez de exigir uma unica frase exata, combina:
#'   Camada 1 (explicito) : frase fixa "prazo legal ... encerrar-se-a em DATA".
#'   Camada 2 (proximidade): qualquer data proxima de um GATILHO_PRAZO (prazo,
#'                           encerra, assinalado, observar, ate...) e que NAO
#'                           esteja proxima de um anti-gatilho (assinatura).
#'
#' Registra o metodo usado (`prazo_metodo`) para que a avaliacao contra o
#' gabarito possa separar prazos de regra forte dos de heuristica.
#'
#' @param texto Texto do documento
#' @return list(prazo_data_iso, prazo_data_original, prazo_encontrado, prazo_metodo)
extrair_prazo <- function(texto) {
  vazio <- list(prazo_data_iso = NA_character_,
                prazo_data_original = NA_character_,
                prazo_encontrado = FALSE,
                prazo_metodo = NA_character_)
  if (is.na(texto) || texto == "") return(vazio)

  # --- Camada 1: padrao explicito ---
  m <- str_match(texto, PADRAO_PRAZO)
  if (!is.na(m[1, 2])) {
    return(.montar_prazo(m[1, 2], metodo = "explicito"))
  }

  # --- Camada 2: gatilho + proximidade ---
  datas <- str_locate_all(texto, "\\d{2}/\\d{2}/\\d{4}")[[1]]
  if (nrow(datas) == 0) return(vazio)

  for (i in seq_len(nrow(datas))) {
    ini <- datas[i, 1]; fim <- datas[i, 2]
    data_txt <- substr(texto, ini, fim)

    # Janela ANTERIOR a data: onde o gatilho de prazo tipicamente aparece
    # ("prazo assinalado (DATA)", "observar o prazo ... DATA").
    antes <- tolower(substr(texto, max(1, ini - JANELA_PRAZO), ini - 1))
    # Janela POSTERIOR: usada para detectar data de assinatura ("DATA, as HH").
    depois <- tolower(substr(texto, fim + 1, min(nchar(texto), fim + 15)))

    tem_gatilho <- any(vapply(GATILHOS_PRAZO,
                              function(g) grepl(g, antes, fixed = TRUE), logical(1)))
    # Anti-gatilho: assinatura aparece ANTES ("assinado ... em DATA") ou o
    # padrao "DATA, as" logo APOS (hora de assinatura).
    assinatura_antes <- any(vapply(tolower(ANTIGATILHOS_PRAZO),
                                   function(a) grepl(a, antes, fixed = TRUE), logical(1)))
    hora_apos <- grepl("^,?\\s*\u00e0s\\b", depois)

    if (tem_gatilho && !assinatura_antes && !hora_apos) {
      return(.montar_prazo(data_txt, metodo = "proximidade"))
    }
  }

  vazio
}

#' Monta o retorno de prazo a partir de uma data dd/mm/aaaa e o metodo.
.montar_prazo <- function(data_original, metodo) {
  iso <- suppressWarnings(dmy(data_original))
  list(prazo_data_iso = if (is.na(iso)) NA_character_ else as.character(iso),
       prazo_data_original = data_original,
       prazo_encontrado = TRUE,
       prazo_metodo = metodo)
}

# -----------------------------------------------------------------------------
# Extracao por documento
# -----------------------------------------------------------------------------

#' Extrai todas as entidades de um unico documento.
#'
#' @param numero_documento Id do documento
#' @param tipo Tipo do documento
#' @param texto Texto completo (corpo)
#' @param bloco_assinaturas Bloco de assinatura (opcional)
#' @return tibble de uma linha com as entidades
.extrair_entidades_documento <- function(numero_documento, tipo, texto,
                                          bloco_assinaturas = NA_character_) {
  dest  <- extrair_destinatario(texto)
  rem   <- extrair_remetente(bloco_assinaturas)
  unid  <- extrair_unidade_emissora(texto)
  prazo <- extrair_prazo(texto)

  # Lista completa de destinatarios (nome/cargo) para preservar multiplos
  # destinatarios sem perder informacao no formato tabular.
  dest_lista <- lapply(dest$destinatarios, function(d) {
    list(nome = d$nome, cargo = d$cargo)
  })

  tibble(
    numero_documento    = as.character(numero_documento),
    tipo                = as.character(tipo),
    unidade_emissora    = unid,
    remetente_nome      = rem$remetente_nome,
    remetente_cargo     = rem$remetente_cargo,
    n_signatarios       = rem$n_signatarios,
    destinatario_nome   = dest$destinatario_nome,
    destinatario_cargo  = dest$destinatario_cargo,
    destinatario_ok     = dest$destinatario_encontrado,
    n_destinatarios     = dest$n_destinatarios,
    destinatarios       = list(dest_lista),
    prazo_data_iso      = prazo$prazo_data_iso,
    prazo_data_original = prazo$prazo_data_original,
    prazo_ok            = prazo$prazo_encontrado,
    prazo_metodo        = prazo$prazo_metodo
  )
}

# -----------------------------------------------------------------------------
# Funcao principal: extrair_entidades_processo()
# -----------------------------------------------------------------------------

#' Extrai entidades/relacoes de todos os documentos com texto de um processo.
#'
#' @param resultado_conteudo list de extrair_conteudo_documentos() OU caminho
#'        do JSON "_conteudo_".
#' @param blocos_assinatura tibble/data.frame opcional com colunas
#'        (numero_documento, bloco_assinaturas), tipicamente vindo do resultado
#'        de text_mining_processo()$por_documento. Se NULL, remetente fica NA.
#' @param dir_processed Diretorio de saida
#' @param persistir Logico — salvar JSON "_entidades_"
#' @return list com: entidades (tibble), meta (list)
extrair_entidades_processo <- function(
    resultado_conteudo,
    blocos_assinatura = NULL,
    dir_processed     = "data/processed",
    persistir         = TRUE
) {
  if (is.character(resultado_conteudo)) {
    if (!file.exists(resultado_conteudo)) {
      stop("[entidades] JSON de conteudo nao encontrado: ", resultado_conteudo)
    }
    resultado_conteudo <- jsonlite::fromJSON(resultado_conteudo, simplifyVector = TRUE)
  }

  numero_processo <- resultado_conteudo$meta$numero_processo
  numero_seguro   <- str_replace_all(numero_processo, "[^0-9A-Za-z]", "_")

  docs <- resultado_conteudo$documentos_conteudo
  docs_com_texto <- docs[!is.na(docs$conteudo_extraido) & docs$conteudo_extraido == TRUE, ]

  cat("[entidades] Processo:", numero_processo, "\n")
  cat("[entidades] Documentos com texto:", nrow(docs_com_texto), "\n")

  # Mapa numero_documento -> bloco_assinaturas (se fornecido)
  mapa_bloco <- .montar_mapa_bloco(blocos_assinatura)

  if (nrow(docs_com_texto) == 0) {
    cat("[entidades] AVISO: nenhum documento com texto. Nada a processar.\n")
    saida <- list(
      meta = list(numero_processo = numero_processo,
                  timestamp = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
                  documentos_processados = 0L),
      entidades = tibble()
    )
    return(invisible(saida))
  }

  linhas <- lapply(seq_len(nrow(docs_com_texto)), function(i) {
    numero <- docs_com_texto$numero_documento[i]
    bloco  <- if (!is.null(mapa_bloco) && numero %in% names(mapa_bloco)) {
      mapa_bloco[[numero]]
    } else {
      NA_character_
    }
    .extrair_entidades_documento(
      numero_documento  = numero,
      tipo              = docs_com_texto$tipo[i],
      texto             = docs_com_texto$texto[i],
      bloco_assinaturas = bloco
    )
  })
  entidades <- bind_rows(linhas)

  # Metricas de cobertura
  n_dest  <- sum(entidades$destinatario_ok, na.rm = TRUE)
  n_prazo <- sum(entidades$prazo_ok, na.rm = TRUE)
  n_rem   <- sum(!is.na(entidades$remetente_nome))
  n_unid  <- sum(!is.na(entidades$unidade_emissora))

  cat("[entidades] --- Resumo ---\n")
  cat("[entidades] Destinatarios extraidos:", n_dest, "de", nrow(entidades), "\n")
  cat("[entidades] Remetentes extraidos   :", n_rem, "de", nrow(entidades), "\n")
  cat("[entidades] Unidades emissoras      :", n_unid, "de", nrow(entidades), "\n")
  cat("[entidades] Prazos extraidos        :", n_prazo, "de", nrow(entidades), "\n")

  saida <- list(
    meta = list(
      numero_processo        = numero_processo,
      timestamp              = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
      documentos_processados = nrow(docs_com_texto),
      destinatarios_extraidos = n_dest,
      remetentes_extraidos    = n_rem,
      unidades_extraidas       = n_unid,
      prazos_extraidos         = n_prazo
    ),
    entidades = entidades
  )

  if (persistir) {
    dir.create(dir_processed, showWarnings = FALSE, recursive = TRUE)
    data_str <- format(Sys.time(), "%Y%m%d")
    nome     <- paste0(numero_seguro, "_entidades_", data_str, ".json")
    caminho  <- file.path(dir_processed, nome)
    write_json(saida, caminho, pretty = TRUE, auto_unbox = TRUE, na = "null")
    cat("[entidades] Persistido em:", caminho, "\n")
  }

  invisible(saida)
}

#' Monta um mapa numero_documento -> bloco_assinaturas a partir de varias
#' formas de entrada (lista por_documento do 05, data.frame, ou NULL).
.montar_mapa_bloco <- function(blocos_assinatura) {
  if (is.null(blocos_assinatura)) return(NULL)

  # Caso 1: lista nomeada por numero_documento (por_documento do 05)
  if (is.list(blocos_assinatura) && !is.data.frame(blocos_assinatura)) {
    return(lapply(blocos_assinatura, function(d) {
      b <- d$bloco_assinaturas
      if (is.null(b) || length(b) == 0) NA_character_ else as.character(b)
    }))
  }

  # Caso 2: data.frame com colunas numero_documento, bloco_assinaturas
  if (is.data.frame(blocos_assinatura) &&
      all(c("numero_documento", "bloco_assinaturas") %in% names(blocos_assinatura))) {
    mapa <- as.list(blocos_assinatura$bloco_assinaturas)
    names(mapa) <- as.character(blocos_assinatura$numero_documento)
    return(mapa)
  }

  NULL
}
