# =============================================================================
# 07_classificacao_supervisionada.R
# Classificacao semantica — MODELO SUPERVISIONADO (Passo 4) (POC IPHAN)
#
# Responsabilidade: caminho 2 da Camada de Classificacao (ver architecture.md):
#   modelo supervisionado simples, COMPARADO ao baseline por dicionario (06).
#
# Principios metodologicos (project-context / research-methodology):
#   - Modelos candidatos: Regressao Logistica (multinomial), Naive Bayes, SVM.
#     Evitar Deep Learning.
#   - Validacao POR PROCESSO para evitar vazamento: usamos
#     LEAVE-ONE-PROCESS-OUT (LOPO) — cada processo e teste exatamente uma vez.
#   - Nao ajustar o modelo sobre os dados de teste. As features (TF-IDF) sao
#     construidas DENTRO de cada fold (so no treino), evitando vazamento do
#     vocabulario/IDF do teste.
#   - Sempre reportar sobre qual conjunto a metrica foi calculada.
#   - Amostra pequena (5 processos): resultados sao de POC, sem generalizacao.
#
# Entrada:
#   - Ground truth consolidado (utils_gabarito.R::consolidar_gabarito()).
#   - Texto dos documentos (JSONs "_conteudo_") para construir as features.
#
# Dependencias de ML (tidymodels e amigos) NAO sao carregadas no source; sao
# verificadas em tempo de execucao para o modulo poder ser lido/estudado mesmo
# sem os pacotes instalados. Instale com:
#   install.packages(c("tidymodels","textrecipes","discrim","naivebayes","glmnet"))
#
# Tecnologias (execucao): tidymodels, textrecipes, discrim/naivebayes/glmnet,
#   yardstick; base: dplyr, stringr, purrr, tibble, jsonlite
# =============================================================================

library(dplyr)
library(stringr)
library(purrr)
library(tibble)
library(jsonlite)

# -----------------------------------------------------------------------------
# Pacotes necessarios para ML (verificados em runtime)
# -----------------------------------------------------------------------------

PKGS_ML <- c("recipes", "textrecipes", "parsnip", "workflows",
             "yardstick", "rsample")

# Pacotes por modelo (engine)
PKGS_ENGINE <- list(
  logistica    = c("nnet"),        # multinom (regressao logistica multinomial)
  naive_bayes  = c("discrim", "naivebayes"),
  svm          = c("kernlab")
)

#' Verifica se os pacotes de ML estao instalados; retorna os faltantes.
#' @param modelo Qual engine sera usado (para checar dependencia especifica)
#' @return character com pacotes faltantes (vazio se tudo ok)
.checar_pkgs_ml <- function(modelo = "logistica") {
  necessarios <- c(PKGS_ML, PKGS_ENGINE[[modelo]])
  necessarios[!vapply(necessarios, requireNamespace, quietly = TRUE,
                      FUN.VALUE = logical(1))]
}

# -----------------------------------------------------------------------------
# Montagem do dataset (texto + rotulo + processo)
# -----------------------------------------------------------------------------

#' Extrai o texto (corpo, sem rodape de assinatura) de um JSON "_conteudo_".
#' @param caminho_conteudo Caminho do JSON _conteudo_
#' @return tibble(numero_documento, texto_corpo)
.textos_do_conteudo <- function(caminho_conteudo) {
  j <- jsonlite::fromJSON(caminho_conteudo, simplifyVector = TRUE)
  d <- j$documentos_conteudo
  d <- d[!is.na(d$conteudo_extraido) & d$conteudo_extraido == TRUE, ]
  tibble(
    numero_documento = as.character(d$numero_documento),
    texto_corpo = vapply(d$texto, function(t) {
      if (is.na(t)) return("")
      str_squish(sub("Documento assinado eletronicamente.*", "", t))
    }, character(1))
  )
}

#' Monta o dataset supervisionado juntando ground truth + textos.
#'
#' @param ground_truth tibble de consolidar_gabarito()$ground_truth
#' @param caminhos_conteudo character — JSONs "_conteudo_" (um por processo).
#'        Se NULL, procura em dir_processed por *_conteudo_*.json.
#' @param dir_processed Diretorio dos processados
#' @param remover_pendentes Logico — descartar docs sem rotulo final
#' @return tibble(numero_processo, numero_documento, classe_final, texto_corpo)
montar_dataset_supervisionado <- function(
    ground_truth,
    caminhos_conteudo = NULL,
    dir_processed     = "data/processed",
    remover_pendentes = TRUE
) {
  if (nrow(ground_truth) == 0) {
    stop("[sup] Ground truth vazio. Rotule e consolide antes de treinar.")
  }

  if (is.null(caminhos_conteudo)) {
    caminhos_conteudo <- list.files(dir_processed,
                                    pattern = "_conteudo_.*\\.json$",
                                    full.names = TRUE)
  }
  if (length(caminhos_conteudo) == 0) {
    stop("[sup] Nenhum JSON _conteudo_ encontrado para obter os textos.")
  }

  textos <- bind_rows(lapply(caminhos_conteudo, .textos_do_conteudo)) |>
    distinct(numero_documento, .keep_all = TRUE)

  ds <- ground_truth |>
    left_join(textos, by = "numero_documento") |>
    mutate(texto_corpo = ifelse(is.na(texto_corpo), "", texto_corpo))

  if (remover_pendentes) {
    ds <- ds |> filter(!pendente, classe_final != "indefinido", classe_final != "")
  }

  sem_texto <- sum(ds$texto_corpo == "")
  if (sem_texto > 0) {
    cat("[sup] AVISO:", sem_texto, "documento(s) do gabarito sem texto correspondente.\n")
  }

  ds |>
    transmute(numero_processo, numero_documento,
              classe = factor(classe_final), texto = texto_corpo) |>
    filter(texto != "")
}

# -----------------------------------------------------------------------------
# Modelo (tidymodels) — construido DENTRO de cada fold
# -----------------------------------------------------------------------------

#' Especifica o modelo (parsnip) conforme a escolha.
#' @param modelo "logistica" | "naive_bayes" | "svm"
#' @return objeto parsnip
.spec_modelo <- function(modelo = "logistica") {
  switch(
    modelo,
    logistica = parsnip::multinom_reg(penalty = 0.01, mixture = 0) |>
      parsnip::set_engine("nnet") |>
      parsnip::set_mode("classification"),
    naive_bayes = parsnip::naive_Bayes() |>
      parsnip::set_engine("naivebayes") |>
      parsnip::set_mode("classification"),
    svm = parsnip::svm_linear() |>
      parsnip::set_engine("kernlab") |>
      parsnip::set_mode("classification"),
    stop("[sup] Modelo desconhecido: ", modelo)
  )
}

#' Monta o recipe de texto -> TF-IDF (textrecipes). Construido no treino de
#' cada fold, entao o vocabulario/IDF vem SO do treino (sem vazamento).
#' @param dados_treino tibble com colunas classe, texto
#' @param max_tokens Limite de tokens no vocabulario
#' @return recipe
.recipe_texto <- function(dados_treino, max_tokens = 500) {
  recipes::recipe(classe ~ texto, data = dados_treino) |>
    textrecipes::step_tokenize(texto) |>
    textrecipes::step_stopwords(texto, language = "pt") |>
    textrecipes::step_tokenfilter(texto, max_tokens = max_tokens) |>
    textrecipes::step_tfidf(texto)
}

# -----------------------------------------------------------------------------
# Leave-One-Process-Out (LOPO)
# -----------------------------------------------------------------------------

#' Executa validacao leave-one-process-out para um modelo supervisionado.
#'
#' Para cada processo p: treina com os demais, prediz em p, acumula as
#' predicoes. Ao final, calcula metricas sobre TODAS as predicoes (cada doc
#' avaliado exatamente uma vez, sempre fora do treino).
#'
#' @param dataset tibble de montar_dataset_supervisionado()
#' @param modelo "logistica" | "naive_bayes" | "svm"
#' @return list(predicoes, metricas, matriz_confusao, por_processo)
avaliar_lopo <- function(dataset, modelo = "logistica") {
  faltantes <- .checar_pkgs_ml(modelo)
  if (length(faltantes) > 0) {
    stop("[sup] Pacotes de ML ausentes para '", modelo, "': ",
         paste(faltantes, collapse = ", "),
         "\n  Instale com: install.packages(c(\"",
         paste(faltantes, collapse = "\",\""), "\"))")
  }

  processos <- unique(dataset$numero_processo)
  if (length(processos) < 2) {
    stop("[sup] LOPO requer >= 2 processos rotulados. Encontrados: ",
         length(processos), ".")
  }

  spec <- .spec_modelo(modelo)
  predicoes <- list()

  for (p in processos) {
    treino <- dataset |> filter(numero_processo != p)
    teste  <- dataset |> filter(numero_processo == p)
    if (nrow(teste) == 0 || nrow(treino) == 0) next

    # Recipe treinado SO no treino do fold (evita vazamento de IDF/vocabulario)
    rec <- .recipe_texto(treino)
    wf  <- workflows::workflow() |>
      workflows::add_recipe(rec) |>
      workflows::add_model(spec)

    fit <- parsnip::fit(wf, data = treino)
    pred <- predict(fit, teste)

    predicoes[[length(predicoes) + 1]] <- tibble(
      numero_processo  = p,
      numero_documento = teste$numero_documento,
      verdadeiro       = teste$classe,
      predito          = pred$.pred_class
    )
  }

  pred_all <- bind_rows(predicoes)
  pred_all$verdadeiro <- factor(pred_all$verdadeiro)
  pred_all$predito    <- factor(pred_all$predito,
                                levels = levels(pred_all$verdadeiro))

  metricas <- .metricas_classificacao(pred_all)
  mc <- yardstick::conf_mat(pred_all, truth = verdadeiro, estimate = predito)

  # Metrica por processo (fold)
  por_processo <- pred_all |>
    group_by(numero_processo) |>
    summarise(
      n = dplyr::n(),
      accuracy = mean(verdadeiro == predito),
      .groups = "drop"
    )

  list(predicoes = pred_all, metricas = metricas,
       matriz_confusao = mc, por_processo = por_processo,
       modelo = modelo)
}

# -----------------------------------------------------------------------------
# Metricas
# -----------------------------------------------------------------------------

#' Calcula metricas de classificacao multiclasse (macro) + accuracy.
#' @param pred tibble(verdadeiro, predito) como fatores de mesmos niveis
#' @return tibble com metric, .estimator, .estimate
.metricas_classificacao <- function(pred) {
  acc  <- yardstick::accuracy(pred, truth = verdadeiro, estimate = predito)
  prec <- yardstick::precision(pred, truth = verdadeiro, estimate = predito,
                               estimator = "macro", na_rm = TRUE)
  rec  <- yardstick::recall(pred, truth = verdadeiro, estimate = predito,
                            estimator = "macro", na_rm = TRUE)
  f1   <- yardstick::f_meas(pred, truth = verdadeiro, estimate = predito,
                            estimator = "macro", na_rm = TRUE)
  bind_rows(acc, prec, rec, f1)
}

#' Avalia o BASELINE por dicionario nos mesmos documentos do gabarito, para
#' comparacao justa (mesmo conjunto, mesma metrica).
#'
#' @param dataset tibble de montar_dataset_supervisionado() (tem texto e classe)
#' @param dicionario dicionario de classes (06); se NULL, carrega
#' @return list(predicoes, metricas)
avaliar_baseline <- function(dataset, dicionario = NULL) {
  if (!exists("classificar_documento")) {
    stop("[sup] classificar_documento() indisponivel. source('R/06_classificacao.R').")
  }
  if (is.null(dicionario)) dicionario <- carregar_dicionario_classes()

  pred <- dataset |>
    mutate(predito = vapply(texto, function(t) {
      classificar_documento(t, tipo = NA_character_, dicionario)$classe
    }, character(1)))

  pred$verdadeiro <- factor(pred$classe)
  niveis <- union(levels(pred$verdadeiro), unique(pred$predito))
  pred$verdadeiro <- factor(pred$verdadeiro, levels = niveis)
  pred$predito    <- factor(pred$predito, levels = niveis)

  list(predicoes = pred, metricas = .metricas_classificacao(pred))
}

# -----------------------------------------------------------------------------
# Funcao principal: comparar baseline vs supervisionado
# -----------------------------------------------------------------------------

#' Executa a comparacao completa: baseline vs modelo supervisionado (LOPO).
#'
#' @param modelo "logistica" | "naive_bayes" | "svm"
#' @param dir_ground_truth Diretorio dos CSVs de rotulagem
#' @param dir_processed Diretorio dos JSONs _conteudo_
#' @param persistir Logico — salvar resultado em output/
#' @return list com metricas do baseline e do supervisionado
comparar_classificadores <- function(
    modelo            = "logistica",
    dir_ground_truth  = "data/ground_truth",
    dir_processed     = "data/processed",
    persistir         = TRUE
) {
  if (!exists("consolidar_gabarito")) {
    stop("[sup] consolidar_gabarito() indisponivel. source('R/utils_gabarito.R').")
  }

  # 1. Consolidar e validar gabarito
  gab <- consolidar_gabarito(dir_ground_truth)
  if (!gab$ok) {
    cat("[sup] Gabarito com erros:\n")
    for (e in gab$erros) cat("  -", e, "\n")
    stop("[sup] Corrija o gabarito antes de treinar.")
  }

  # 2. Montar dataset (texto + rotulo + processo)
  dataset <- montar_dataset_supervisionado(gab$ground_truth,
                                           dir_processed = dir_processed)
  cat("[sup] Dataset:", nrow(dataset), "documentos |",
      dplyr::n_distinct(dataset$numero_processo), "processos |",
      nlevels(dataset$classe), "classes\n")

  # 3. Baseline (mesmo conjunto)
  base_res <- avaliar_baseline(dataset)
  cat("\n[sup] === BASELINE (dicionario) ===\n")
  print(base_res$metricas)

  # 4. Supervisionado (LOPO)
  sup_res <- avaliar_lopo(dataset, modelo = modelo)
  cat("\n[sup] === SUPERVISIONADO (", modelo, ", LOPO) ===\n", sep = "")
  print(sup_res$metricas)
  cat("\n[sup] Accuracy por processo (fold):\n")
  print(sup_res$por_processo)

  resultado <- list(
    modelo        = modelo,
    n_documentos  = nrow(dataset),
    n_processos   = dplyr::n_distinct(dataset$numero_processo),
    baseline      = base_res$metricas,
    supervisionado = sup_res$metricas,
    matriz_confusao = sup_res$matriz_confusao,
    por_processo  = sup_res$por_processo
  )

  if (persistir) {
    dir.create("output", showWarnings = FALSE, recursive = TRUE)
    data_str <- format(Sys.time(), "%Y%m%d")
    caminho <- file.path("output", paste0("comparacao_classificacao_", modelo, "_", data_str, ".json"))
    saida_json <- list(
      modelo = modelo,
      n_documentos = resultado$n_documentos,
      n_processos = resultado$n_processos,
      baseline = base_res$metricas,
      supervisionado = sup_res$metricas,
      por_processo = sup_res$por_processo
    )
    jsonlite::write_json(saida_json, caminho, pretty = TRUE, auto_unbox = TRUE)
    cat("\n[sup] Comparacao salva em:", caminho, "\n")
  }

  invisible(resultado)
}
