# executar_scraping_local.R
# Roda o scraper contra o HTML local salvo em Paginas/
# Usado quando a URL de sessão do SEI já expirou.

setwd(dirname(parent.frame(2)$ofile) %||% getwd())

source("R/02_sei_scraping.R")

resultado <- scrape_processo_html_local(
  caminho_html  = "Paginas/Pagina Processo Buscado.html",
  url_original  = "https://sei.iphan.gov.br/sei/modulos/pesquisa/md_pesq_processo_exibir.php?iI3OtHvPArITY997V09rhsSkbDKbaYSycOHqqF2xsM0IaDkkEyJpus7kCPb435VNEAb16AAxmJKUdrsNWVIqQw02_CutLpMKF6Yxd-0vMVC_Qpr7vnJcx6Gys6LheGMm"
)

cat("\n========== DOCUMENTOS ==========\n")
print(resultado$documentos[, c("numero_documento","tipo","data_documento","unidade_sigla","acesso")])

cat("\n========== ANDAMENTOS (primeiros 10) ==========\n")
print(head(resultado$andamentos[, c("data_hora","unidade_sigla","descricao","status")], 10))