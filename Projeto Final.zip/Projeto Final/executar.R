# =============================================================================
# executar.R — Ponto de entrada por linha de comando para o pipeline completo
#
# Executa TODAS as etapas implementadas da POC para uma URL de processo do SEI:
#   Etapa 1: Scraping estrutural   (02_sei_scraping.R)
#   Etapa 2: Extracao de conteudo  (03_parser_documentos.R)
#   Etapa 3: Text Mining           (05_text_mining.R)
#
# Uso (PowerShell):
#   & "C:\Program Files\R\R-4.6.1\bin\Rscript.exe" executar.R "URL_DO_PROCESSO"
#
# Observacoes:
#   - A URL do SEI Pesquisa Publica contem um token de sessao TEMPORARIO. Se ela
#     expirar, o scraping falha. Nesse caso use executar_scraping_local.R contra
#     o HTML salvo em Paginas/.
#   - Cada etapa persiste seu resultado em data/processed/ antes da proxima.
# =============================================================================

args <- commandArgs(trailingOnly = TRUE)

if (length(args) == 0 || is.na(args[1]) || nchar(trimws(args[1])) == 0) {
  cat("Uso: Rscript executar.R \"URL_DO_PROCESSO\"\n\n")
  cat("Exemplo:\n")
  cat("  Rscript executar.R \"https://sei.iphan.gov.br/sei/modulos/pesquisa/md_pesq_processo_exibir.php?TOKEN\"\n")
  quit(status = 1)
}

url <- trimws(args[1])

if (!grepl("^https?://", url)) {
  cat("[executar] ERRO: o argumento nao parece uma URL valida:\n  ", url, "\n")
  cat("[executar] A URL deve comecar com http:// ou https://\n")
  quit(status = 1)
}

cat("[executar] Carregando modulos (main.R)...\n")
source("main.R")

resultado <- analisar_processo(url)

cat("\n[executar] Pipeline concluido. Resultados persistidos em data/processed/.\n")
