# =============================================================================
# main.R
# Ponto de entrada da POC de Mineracao de Processos de Licenciamento Ambiental
#
# Este arquivo carrega todos os modulos e expoe a funcao principal:
#   analisar_processo(url)
# & "C:\Program Files\R\R-4.6.1\bin\Rscript.exe" executar.R "https://sei.iphan.gov.br/sei/modulos/pesquisa/md_pesq_processo_exibir.php?iI3OtHvPArITY997V09rhsSkbDKbaYSycOHqqF2xsM0IaDkkEyJpus7kCPb435VNEAb16AAxmJKUdrsNWVIqQ1fbD0RZVpvDH361Oo6q4j5Pb3159ClCGO7vlH1u95S5"
# Uso (reproducao do experimento):
#   source("main.R")
#   resultado <- analisar_processo("https://sei.iphan.gov.br/...")
# =============================================================================

# Verificar dependencias minimas das etapas implementadas
pkgs_necessarios <- c("httr2", "rvest", "xml2", "tidyverse",
                       "lubridate", "stringr", "jsonlite", "purrr",
                       "tidytext", "stopwords", "stringi")

pkgs_faltantes <- pkgs_necessarios[!vapply(pkgs_necessarios, requireNamespace,
                                            quietly = TRUE, FUN.VALUE = logical(1))]
if (length(pkgs_faltantes) > 0) {
  message("Instalando pacotes necessarios: ", paste(pkgs_faltantes, collapse = ", "))
  install.packages(pkgs_faltantes)
}

# Carregar modulos na ordem de dependencia
# NB: R/01_amostragem.R NAO e carregado aqui de proposito. Ele e a etapa de
#     amostragem (executada uma unica vez para sortear os 5 processos) e roda
#     codigo no nivel do arquivo — instala pacman e baixa uma planilha do Google
#     Sheets ao ser carregado. analisar_processo() nao depende dele. Para
#     reproduzir a amostragem, rode R/01_amostragem.R separadamente.
source("R/02_sei_scraping.R")
source("R/03_parser_documentos.R")
source("R/04_entidades.R")
source("R/05_text_mining.R")
source("R/06_classificacao.R")

# =============================================================================
# Funcao principal — sera expandida nas proximas etapas
# =============================================================================

#' Analisa um processo do SEI executando as etapas da POC ja implementadas.
#'
#' Etapas implementadas:
#'   [x] Etapa 1: Aquisicao e scraping estrutural
#'   [x] Etapa 2: Extracao de conteudo dos documentos nativos
#'   [x] Etapa 3: Text Mining (normalizacao, datas, tokens, TF-IDF)
#'   [x] Etapa 3b: Extracao de entidades (remetente, destinatario, unidade, prazo)
#'   [x] Etapa 4: Classificacao semantica — baseline por dicionario
#'   [ ] Classificacao semantica — modelo supervisionado (requer gabarito)
#'   [ ] Process Mining / Event Log           (etapa futura)
#'   [ ] Analise de conformidade normativa    (etapa futura)
#'   [ ] Avaliacao contra gabarito            (etapa futura)
#'
#' @param url URL do processo no SEI Pesquisa Publica
#' @param extrair_conteudo Logico — executar a extracao de conteudo (Etapa 2)
#' @param text_mining Logico — executar o text mining (Etapa 3)
#' @param extrair_entidades Logico — executar a extracao de entidades (Etapa 3b)
#' @return list com os resultados das etapas executadas
analisar_processo <- function(url, extrair_conteudo = TRUE, text_mining = TRUE,
                              extrair_entidades = TRUE, classificar = TRUE) {
  cat("=== POC IPHAN — Iniciando analise ===\n")
  cat("URL:", url, "\n\n")

  # ---- Etapa 1: Scraping estrutural ----
  cat("--- Etapa 1: Scraping estrutural ---\n")
  dados_scraping <- scrape_processo_sei(url)

  cat("\n[Etapa 1] Processo:", dados_scraping$cabecalho$numero_processo, "\n")
  cat("[Etapa 1] Documentos:", dados_scraping$meta$total_documentos,
      "| Andamentos:", dados_scraping$meta$total_andamentos, "\n")

  # ---- Etapa 2: Extracao de conteudo dos documentos nativos ----
  dados_conteudo <- NULL
  if (extrair_conteudo) {
    cat("\n--- Etapa 2: Extracao de conteudo ---\n")
    dados_conteudo <- extrair_conteudo_documentos(dados_scraping)
    cat("\n[Etapa 2] Nativos extraidos:", dados_conteudo$meta$conteudo_extraido,
        "de", dados_conteudo$meta$nativos_elegiveis,
        "(cobertura:", dados_conteudo$meta$cobertura_conteudo, ")\n")
  }

  # ---- Etapa 3: Text Mining ----
  dados_textmining <- NULL
  if (text_mining && !is.null(dados_conteudo)) {
    cat("\n--- Etapa 3: Text Mining ---\n")
    dados_textmining <- text_mining_processo(dados_conteudo)
    cat("\n[Etapa 3] Tokens:", dados_textmining$meta$tokens_totais,
        "| Vocabulario:", dados_textmining$meta$vocabulario_unico,
        "| Datas:", dados_textmining$meta$datas_extraidas_total, "\n")
  }

  # ---- Etapa 3b: Extracao de entidades (remetente/destinatario/unidade/prazo) ----
  dados_entidades <- NULL
  if (extrair_entidades && !is.null(dados_conteudo)) {
    cat("\n--- Etapa 3b: Extracao de entidades ---\n")
    # Reaproveita os blocos de assinatura do text mining (se disponiveis) para
    # extrair o remetente/signatario.
    blocos <- if (!is.null(dados_textmining)) dados_textmining$por_documento else NULL
    dados_entidades <- extrair_entidades_processo(dados_conteudo, blocos_assinatura = blocos)
    cat("\n[Etapa 3b] Destinatarios:", dados_entidades$meta$destinatarios_extraidos,
        "| Remetentes:", dados_entidades$meta$remetentes_extraidos,
        "| Prazos:", dados_entidades$meta$prazos_extraidos, "\n")
  }

  # ---- Etapa 4: Classificacao semantica (baseline por dicionario) ----
  dados_classificacao <- NULL
  if (classificar && !is.null(dados_conteudo)) {
    cat("\n--- Etapa 4: Classificacao semantica (baseline) ---\n")
    dados_classificacao <- classificar_processo(dados_conteudo)
    cat("\n[Etapa 4] Documentos classificados:",
        dados_classificacao$meta$documentos_processados,
        "| Indefinidos:", dados_classificacao$meta$indefinidos, "\n")
  }

  cat("\n=== Analise concluida ===\n")

  invisible(list(
    scraping      = dados_scraping,
    conteudo      = dados_conteudo,
    textmining    = dados_textmining,
    entidades     = dados_entidades,
    classificacao = dados_classificacao
  ))
}