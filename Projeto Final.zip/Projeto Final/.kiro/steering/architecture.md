---
inclusion: always
---
# Arquitetura da POC

## Organização

Estrutura preferencial:

```text
R/
  01_amostragem.R
  02_sei_scraping.R
  03_parser_documentos.R
  04_assinaturas.R
  05_text_mining.R
  06_classificacao.R
  07_event_log.R
  08_normativas.R
  09_prazos.R
  10_grafo.R
  11_avaliacao.R
  12_pipeline.R

data/
  raw/
  processed/
  models/
  normativas/
  ground_truth/

output/

tests/

config/

main.R
README.md
```

## Separação das camadas

### Aquisição

Responsável exclusivamente por acessar o SEI e armazenar dados brutos.

Tecnologias preferenciais:

* httr2
* rvest
* xml2

RSelenium somente se for comprovadamente necessário devido à dependência de JavaScript.

### Dados estruturais

Responsável por produzir:

* documentos;
* andamentos;
* assinaturas.

### Conteúdo

Responsável por:

* baixar documentos públicos;
* extrair HTML/PDF;
* produzir texto;
* registrar documentos sem texto.

### Text Mining

Responsável por:

* normalização;
* tokenização;
* stopwords;
* extração de datas;
* identificação de termos;
* preparação de atributos;
* TF-IDF.

### Classificação

Possuir dois caminhos:

1. baseline por regras/dicionário;
2. modelo supervisionado simples.

Modelos candidatos:

* Logistic Regression;
* Naive Bayes;
* SVM.

Evitar Deep Learning.

### Process Mining

Construir event log com pelo menos:

* case_id;
* activity;
* timestamp.

Adicionar, quando disponível:

* resource;
* unidade;
* documento;
* resultado.

### Normativas

As regras da IN nº 06/2025 devem estar armazenadas de forma estruturada.

Evitar hardcode.

### Prazos

Entrada:

* evento inicial;
* evento final;
* regra normativa.

Saída:

* prazo normativo;
* dias decorridos;
* excesso;
* dentro do prazo;
* status.

Quando aplicável, considerar a data da última assinatura como encerramento do ato.

### Grafos

Manter separados:

1. grafo regulatório;
2. grafo organizacional;
3. grafo de pendências.

O grafo regulatório é a espinha dorsal da análise de conformidade.

O grafo organizacional explica a tramitação entre unidades.

O grafo de pendências é derivado dessas informações.

### Persistência

Cada etapa deve persistir seus resultados antes da próxima etapa.

A coleta de rede não deve ser necessária para executar etapas posteriores.

### Pipeline

A função final da POC deverá ser conceitualmente:

```r
analisar_processo(url)
```

Ela serve para reproduzir o experimento.

Não representa um produto implantado.
