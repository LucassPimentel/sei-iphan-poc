# scrapar.R — Uso: Rscript scrapar.R "URL_DO_PROCESSO"
# Exemplo:
#   Rscript scrapar.R "https://sei.iphan.gov.br/sei/modulos/pesquisa/md_pesq_processo_exibir.php?TOKEN"

args <- commandArgs(trailingOnly = TRUE)

if (length(args) == 0) {
  cat("Uso: Rscript scrapar.R \"URL_DO_PROCESSO\"\n")
  quit(status = 1)
}

url <- args[1]

suppressPackageStartupMessages({
  library(httr2); library(rvest); library(xml2)
  library(tidyverse); library(lubridate); library(stringr); library(jsonlite)
})

source("R/02_sei_scraping.R")

r <- scrape_processo_sei(url)

cat("\n========== RESULTADO ==========\n")
cat("Processo         :", r$cabecalho$numero_processo, "\n")
cat("Tipo             :", r$cabecalho$tipo, "\n")
cat("Data de geracao  :", r$cabecalho$data_geracao, "\n")
cat("Processo restrito:", r$meta$processo_restrito, "\n")
cat("Documentos       :", r$meta$total_documentos,
    "| Publicos:", r$meta$documentos_publicos,
    "| Restritos:", r$meta$documentos_restritos, "\n")
cat("Andamentos       :", r$meta$total_andamentos, "\n")
cat("HTML salvo em    :", r$meta$html_salvo_em, "\n")

cat("\n--- DOCUMENTOS ---\n")
print(r$documentos[, c("numero_documento", "tipo", "data_documento", "unidade_sigla", "acesso")])

cat("\n--- ANDAMENTOS ---\n")
print(r$andamentos[, c("data_hora", "unidade_sigla", "descricao", "status")])
